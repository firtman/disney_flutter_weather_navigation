import 'package:flutter/material.dart';

import 'api.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 227, 112, 5)),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Disney Weather'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text(title),
        ),
        body: Column(
          children: [
            const Center(child: Text("Weather in Orlando")),
            Center(
              child: FutureBuilder(
                future: API().getTemperature("Paris"),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    print(snapshot.error);
                    return Text("ERROR :(");
                  } else if (snapshot.hasData) {
                    final temperature = snapshot.data;
                    return Text("$temperature F");
                  } else {
                    return CircularProgressIndicator();
                  }
                },
              ),
            ),
          ],
        ));
  }
}
